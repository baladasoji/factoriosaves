data:extend({
    {
        type = "int-setting",
        name = "far-reach-build-distance-bonus",
        setting_type = "runtime-global",
        default_value = 150,
        maximum_value = 100000,
        minimum_value = 0,
        order = "1"
    },
    {
        type = "int-setting",
        name = "far-reach-reach-distance-bonus",
        setting_type = "runtime-global",
        default_value = 150,
        maximum_value = 100000,
        minimum_value = 0,
        order = "2"
    },
    {
        type = "int-setting",
        name = "far-reach-resource-reach-distance-bonus",
        setting_type = "runtime-global",
        default_value = 150,
        maximum_value = 100000,
        minimum_value = 0,
        order = "3"
    },
    {
        type = "int-setting",
        name = "far-reach-item-drop-distance-bonus",
        setting_type = "runtime-global",
        default_value = 150,
        maximum_value = 1000,
        minimum_value = 0,
        order = "4"
    },
    {
        type = "int-setting",
        name = "far-reach-item-pickup-distance-bonus",
        setting_type = "runtime-global",
        default_value = 0,
        maximum_value = 100,
        minimum_value = 0,
        order = "5"
    }
})
